package com.margsoft.pcpndt.Fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.Activities.CenterDetailActivity;
import com.margsoft.pcpndt.Activities.LoginActivity;
import com.margsoft.pcpndt.Activities.MainActivity;
import com.margsoft.pcpndt.Adapter.DashboardAdapter;
import com.margsoft.pcpndt.Adapter.DashboardGridAdapter;
import com.margsoft.pcpndt.Adapter.HistoryAdapter;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.InspecList;
import com.margsoft.pcpndt.Responses.InspecResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment  extends Fragment {
    ImageView imageView;
    View v;
    ProgressDialog progressDialog;
    List<InspecList> inspecLists = new ArrayList<>();
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    DashboardAdapter dashboardAdapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_dashboard, container, false);
        progressDialog = new ProgressDialog(getActivity());
        String id = PrefUtils.getFromPrefs(getActivity(),PrefUtils.Id);
        GetList(id);
        ImageView back = v.findViewById(R.id.back);
        back.setVisibility(View.GONE);
        imageView = v.findViewById(R.id.no_data_img);
        recyclerView = v.findViewById(R.id.dashboard_recycler);
        linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

//        recyclerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Intent intent = new Intent(getActivity(), CenterDetailActivity.class);
//                startActivity(intent);
//            }
//
//        });
        return v;
    }
    public void GetList(String id){
        progressDialog.setMessage("Submitting Data...");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        RestApiService authApiHelper = ApiClient.getClient_minetag(getActivity()).create(RestApiService.class);
        Call<InspecResponse> call2 = authApiHelper.get_inspection_list_pending(id);
        call2.enqueue(new Callback<InspecResponse>() {
            @Override
            public void onResponse(Call<InspecResponse> call, Response<InspecResponse> response) {
                final InspecResponse userList = response.body();
                if(userList.getError()==0){
                    if(userList.getResults().isEmpty()){
                        recyclerView.setVisibility(View.GONE);
                        imageView.setVisibility(View.VISIBLE);
                    }
                    else{
                        for(InspecList feedback : userList.getResults()){
                            inspecLists.add(feedback);
                        }
                        dashboardAdapter = new DashboardAdapter(getActivity(),recyclerView,inspecLists);
                        recyclerView.setAdapter(dashboardAdapter);
                    }

                }
                progressDialog.dismiss();

            }
            @Override
            public void onFailure(Call<InspecResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(getActivity(), "fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
//    public void logout(View v){
//        PrefUtils.saveToPrefs(getActivity(),PrefUtils.Start_Status,"0");
//        Intent intent = new Intent(getActivity(), LoginActivity.class);
//        startActivity(intent);
//        getActivity().finish();
//       // Toast.makeText(getActivity(),"LOGOUT",Toast.LENGTH_SHORT).show();
//    }
}
package com.margsoft.pcpndt.Fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.Adapter.DashboardAdapter;
import com.margsoft.pcpndt.Adapter.HistoryAdapter;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.InspecList;
import com.margsoft.pcpndt.Responses.InspecResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoryFragment extends Fragment {
    View v;
    LinearLayoutManager layoutManager;
    RecyclerView recyclerView;
    HistoryAdapter historyAdapter;
    List<InspecList> inspecLists = new ArrayList<>();
    ProgressDialog progressDialog;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_history, container, false);
        progressDialog = new ProgressDialog(getActivity());
        String id = PrefUtils.getFromPrefs(getActivity(),PrefUtils.Id);
        GetList(id);
        ImageView back = v.findViewById(R.id.back);
        back.setVisibility(View.GONE);
        recyclerView = v.findViewById(R.id.history_recycler);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        return v;
    }

    public void GetList(String id){
        progressDialog.setMessage("Please Wait");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        RestApiService authApiHelper = ApiClient.getClient_minetag(getActivity()).create(RestApiService.class);
        Call<InspecResponse> call2 = authApiHelper.get_inspection_list_completed(id);
        call2.enqueue(new Callback<InspecResponse>() {
            @Override
            public void onResponse(Call<InspecResponse> call, Response<InspecResponse> response) {
                final InspecResponse userList = response.body();
                if(userList.getError()==0){
                    if(userList.getResults().isEmpty()){
                        recyclerView.setVisibility(View.GONE);
                        // imageView.setVisibility(View.VISIBLE);
                    }
                    else{
                        for(InspecList feedback : userList.getResults()){
                            inspecLists.add(feedback);
                        }
                        historyAdapter = new HistoryAdapter(getActivity(),recyclerView,inspecLists);
                        recyclerView.setAdapter(historyAdapter);
                    }

                }
                progressDialog.dismiss();
            }
            @Override
            public void onFailure(Call<InspecResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(getActivity(), "fail", Toast.LENGTH_SHORT).show();
//                progressDialog.dismiss();
            }
        });
    }
}

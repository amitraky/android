package com.margsoft.pcpndt.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.InspecList;

import java.util.ArrayList;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private Context context;
    //  private List<PreviousFeedList> modelList;
    RecyclerView recyclerView;
    List<InspecList> inspecLists = new ArrayList<>();

    public HistoryAdapter(Context context, RecyclerView recyclerView,List<InspecList> inspecLists) {
        this.context = context;
        this.inspecLists = inspecLists;
        this.recyclerView = recyclerView;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.itemView.setTag(inspecLists.get(position));
        InspecList pu = inspecLists.get(position);
        holder.center_name.setText(pu.getUnRegCentreName());
        holder.center_add.setText(pu.getUnRegCentreAddress());
        holder.date.setText(pu.getLastModifiedOn());
        holder.remark.setText(pu.getRemark());
    }
    @Override
    public int getItemCount() {
        return inspecLists.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView center_name,center_add,date,remark;
        public ViewHolder(View itemView) {
            super(itemView);
            center_name = itemView.findViewById(R.id.center_name);
            center_add = itemView.findViewById(R.id.center_add);
            date = itemView.findViewById(R.id.date);
            remark = itemView.findViewById(R.id.remark);

        }
    }
}

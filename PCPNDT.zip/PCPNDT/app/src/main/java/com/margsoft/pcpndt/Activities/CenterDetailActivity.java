package com.margsoft.pcpndt.Activities;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.util.Calendar;
import java.util.prefs.PreferenceChangeEvent;

public class CenterDetailActivity extends AppCompatActivity {
    private int mYear, mMonth, mDay;
    EditText date_ed,remark;
    String center_name_str, center_add_str;
    TextView center_name,center_add;
    CheckBox decoy;
    String decoy_str="no";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_center_detail);

        center_name_str = PrefUtils.getFromPrefs(CenterDetailActivity.this,PrefUtils.Center_Name);
        center_add_str = PrefUtils.getFromPrefs(CenterDetailActivity.this,PrefUtils.Center_Address);
        center_name = findViewById(R.id.center_name);
        center_add = findViewById(R.id.center_add);
        center_name.setText(center_name_str);
        center_add.setText(center_add_str);
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        date_ed= findViewById(R.id.start_date_text);
        remark = findViewById(R.id.remark);
        decoy = findViewById(R.id.decoy);

        date_ed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenCalendar();
            }
        });
    }
    public void logout(View v){
        Toast.makeText(CenterDetailActivity.this,"LOGOUT",Toast.LENGTH_SHORT).show();
    }
    public void validation(View v){
        if(decoy.isChecked()){
            decoy_str= "yes";
        }
        if(date_ed.getText().equals("")){
            date_ed.setError("Please Select Date");
        }
        else {
            PrefUtils.saveToPrefs(CenterDetailActivity.this,PrefUtils.Decoy,decoy_str);
            PrefUtils.saveToPrefs(CenterDetailActivity.this,PrefUtils.Remark,remark.getText().toString());
            Intent intent = new Intent(CenterDetailActivity.this, ChecklistActivity.class);
            startActivity(intent);
        }


    }
    private void OpenCalendar() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(CenterDetailActivity.this,R.style.DatePicker,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        String month = null,date = null;
                        if((monthOfYear+1) < 10){
                            month = "0"+ (monthOfYear+1);
                        }
                        else{
                            month = String.valueOf(monthOfYear+1);
                        }
                        if(dayOfMonth < 10){
                            date  = "0"+ dayOfMonth ;
                        }
                        else {
                            date = String.valueOf(dayOfMonth);
                        }
                        date_ed.setText(year + "-" + month + "-" + date);
                        PrefUtils.saveToPrefs(CenterDetailActivity.this,PrefUtils.Date,date_ed.getText().toString());
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }
}
package com.margsoft.pcpndt.Fragments;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.Activities.MainActivity;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.UpdateProResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {
    View v;
    TextView name,username,mobile,address,edit;
    EditText name_ed;
    DashboardFragment dashboardFragment = new DashboardFragment();
    ProgressDialog progressDialog;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_profile, container, false);
        TextView backtohome = (TextView) v.findViewById(R.id.backtohome);
        progressDialog = new ProgressDialog(getActivity());
        edit = v.findViewById(R.id.edit);
        name = v.findViewById(R.id.name);
        name_ed= v.findViewById(R.id.name_ed);
        username = v.findViewById(R.id.username);
        mobile = v.findViewById(R.id.mobile);
        address = v.findViewById(R.id.address);
        name.setText(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Name));
        username.setText(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Username));
        mobile.setText(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Mobile));
        address.setText(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Address));
        backtohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).loadFragment(dashboardFragment);
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit.getText().equals("Edit")){
                    name_ed.setVisibility(View.VISIBLE);
                    name.setVisibility(View.GONE);
                    edit.setText("Update");
                }
                else  if(edit.getText().equals("Update")){
                    update();
                }
                //openDialog(v);
            }
        });
        return v;
    }
    public void  update(){
        progressDialog.setMessage("Please Wait...");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        RestApiService authApiHelper = ApiClient.getClient_minetag(getActivity()).create(RestApiService.class);
        Call<UpdateProResponse> call2 = authApiHelper.update_profile(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Id),name_ed.getText().toString(),PrefUtils.getFromPrefs(getActivity(),PrefUtils.Mobile),
              "" , PrefUtils.getFromPrefs(getActivity(),PrefUtils.Address));
        call2.enqueue(new Callback<UpdateProResponse>() {
            @Override
            public void onResponse(Call<UpdateProResponse> call, Response<UpdateProResponse> response) {
                final UpdateProResponse userList = response.body();
                if(userList.getError()==0){
                    PrefUtils.saveToPrefs(getActivity(),PrefUtils.Name,name_ed.getText().toString());
                    name_ed.setVisibility(View.GONE);
                    name.setVisibility(View.VISIBLE);
                    name.setText(PrefUtils.getFromPrefs(getActivity(),PrefUtils.Name));
                    edit.setText("Edit");
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), userList.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<UpdateProResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(getActivity(), "fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
}
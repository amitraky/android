package com.margsoft.pcpndt.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.LoginResponse;
import com.margsoft.pcpndt.Responses.TokenResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    EditText ed_phnnum;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        progressDialog = new ProgressDialog(LoginActivity.this);
        ed_phnnum = findViewById(R.id.ed_phnnum);
    }
    public void get_otp_click(View v){
        if(isOnline())
            validation();
        else
            Toast.makeText(LoginActivity.this, "No internet connection", Toast.LENGTH_SHORT).show();
//        Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
//        startActivity(intent);
    }
    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
    public void validation(){
        String  phnnum_str = ed_phnnum.getText().toString();
        if(phnnum_str.matches("")){
            ed_phnnum.setError("Enter Phone Number");
        }
//        else if(phnnum_str.length()<10){
//            ed_phnnum.setError("Enter Valid Phone Number");
//        }
        else{
            GetOtp(phnnum_str);
        }
    }
    public void  GetOtp(final String phone_number){
        progressDialog.setMessage("Please Wait...");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        RestApiService authApiHelper = ApiClient.getClient_minetag(this).create(RestApiService.class);
        Call<TokenResponse> call2 = authApiHelper.token_generate(phone_number);
        call2.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                final TokenResponse userList = response.body();
                if(userList.getMessage().equals("OTP Sent")){
                    Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
                    startActivity(intent);
                    Toast.makeText(LoginActivity.this,userList.getResults().getToken().toString(),Toast.LENGTH_SHORT).show();
                    PrefUtils.saveToPrefs(LoginActivity.this,PrefUtils.Number,phone_number);
                }
//                if (userList.getStatus() != 0) {
//
//                }
            }
            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(LoginActivity.this, "fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

    }
}
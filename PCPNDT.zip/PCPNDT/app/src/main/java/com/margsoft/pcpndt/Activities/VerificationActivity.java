package com.margsoft.pcpndt.Activities;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.LoginDetail;
import com.margsoft.pcpndt.Responses.LoginResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerificationActivity extends AppCompatActivity {
    EditText ed_otp;
    ProgressDialog progressDialog;
    List<LoginDetail> loginDetails = new ArrayList<>();
    String  otp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);
        progressDialog = new ProgressDialog(VerificationActivity.this);
        ed_otp = findViewById(R.id.ed_otp);
    }
    public void verify_btn(View v){
        if(isOnline())
            validation();
        else
            Toast.makeText(VerificationActivity.this, "No internet connection", Toast.LENGTH_SHORT).show();
//        Intent intent = new Intent(VerificationActivity.this, MainActivity.class);
//        startActivity(intent);
    }
    protected boolean isOnline(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
    public void validation(){
        String  otp_str = ed_otp.getText().toString();
        if(otp_str.matches("")){
            ed_otp.setError("Enter OTP");
        }
        else if(otp_str.length()<4){
            ed_otp.setError("Enter Valid OTP");
        }
        else{
            Verify(otp_str);
        }
    }
    public void Verify(String otp){
        progressDialog.setMessage("Please Wait...");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        String numebr = PrefUtils.getFromPrefs(VerificationActivity.this,PrefUtils.Number);
        RestApiService authApiHelper = ApiClient.getClient_minetag(this).create(RestApiService.class);
        Call<LoginResponse> call2 = authApiHelper.verify_token(numebr, otp);
        call2.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                final LoginResponse userList = response.body();
                if (userList.getMessage().equals("OTP verify success")) {
                    if(userList.getResults()!=null){
                        for ( LoginDetail feedbackModel : userList.getResults()) {
                            loginDetails.add(feedbackModel);
                        }
                        for(int i = 0; i<loginDetails.size();i++){
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Id,loginDetails.get(i).getId().toString());
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Name,loginDetails.get(i).getName().toString());
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Address,loginDetails.get(i).getAddress().toString());
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Mobile,loginDetails.get(i).getPhone().toString());
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Username,loginDetails.get(i).getUsername().toString());
                            PrefUtils.saveToPrefs(VerificationActivity.this,PrefUtils.Start_Status,"1");
                        }
                        Intent intent = new Intent(VerificationActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
                else {
                    Toast.makeText(VerificationActivity.this,userList.getMessage(),Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }
            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(VerificationActivity.this, "fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
}
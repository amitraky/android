package com.margsoft.pcpndt.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.margsoft.pcpndt.Activities.CenterDetailActivity;
import com.margsoft.pcpndt.Activities.ChecklistActivity;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.InspecList;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.util.ArrayList;
import java.util.List;

public class DashboardAdapter extends RecyclerView.Adapter<DashboardAdapter.ViewHolder> {

    private Context context;
    RecyclerView recyclerView;
    List<InspecList> inspecLists = new ArrayList<>();

    public DashboardAdapter(Context context, RecyclerView recyclerView,List<InspecList> inspecLists) {
        this.context = context;
        this.inspecLists = inspecLists;
        this.recyclerView = recyclerView;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.assigned_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        holder.itemView.setTag(inspecLists.get(position));
        InspecList pu = inspecLists.get(position);
        holder.center_name.setText(pu.getUnRegCentreName());
        holder.center_add.setText(pu.getUnRegCentreAddress());
    }
    @Override
    public int getItemCount() {
        return inspecLists.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView center_name,center_add;
        public ViewHolder(View itemView) {
            super(itemView);
            center_name = itemView.findViewById(R.id.center_name);
            center_add = itemView.findViewById(R.id.center_add);
            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        InspecList clickedDataItem = inspecLists.get(pos);
                        PrefUtils.saveToPrefs(context,PrefUtils.Inspection_Id,clickedDataItem.getId());
                        PrefUtils.saveToPrefs(context,PrefUtils.Center_Address,clickedDataItem.getUnRegCentreAddress());
                        PrefUtils.saveToPrefs(context,PrefUtils.Center_Name,clickedDataItem.getUnRegCentreName());
                        Intent intent = new Intent(context, CenterDetailActivity.class);
                        context.startActivity(intent);
                    }
                }
            });
        }
    }
}

package com.margsoft.pcpndt.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.margsoft.pcpndt.R;

import java.util.List;

public class DashboardGridAdapter  extends BaseAdapter {
    Context context;
    LayoutInflater inflter;
    public DashboardGridAdapter(Context applicationContext) {
        this.context = applicationContext;
        inflter = (LayoutInflater.from(applicationContext));
    }
    @Override
    public int getCount() {
        return 3;
    }
    @Override
    public Object getItem(int i) {
        return null;
    }
    @Override
    public long getItemId(int i) {
        return 0;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.dashboard_grid_layout, null);// inflate the layout
        RelativeLayout grid_view_items= view.findViewById(R.id.grid_view_items);

        return view;
    }
}
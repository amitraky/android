package com.margsoft.pcpndt.Responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginDivision {
    @SerializedName("DivisionKey")
    @Expose
    private Integer divisionKey;
    @SerializedName("Name")
    @Expose
    private String name;

    public Integer getDivisionKey() {
        return divisionKey;
    }

    public void setDivisionKey(Integer divisionKey) {
        this.divisionKey = divisionKey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

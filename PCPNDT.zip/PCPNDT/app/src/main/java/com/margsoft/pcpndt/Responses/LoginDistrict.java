package com.margsoft.pcpndt.Responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginDistrict {
    @SerializedName("DistrictKey")
    @Expose
    private Integer districtKey;
    @SerializedName("Name")
    @Expose
    private String name;

    public Integer getDistrictKey() {
        return districtKey;
    }

    public void setDistrictKey(Integer districtKey) {
        this.districtKey = districtKey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

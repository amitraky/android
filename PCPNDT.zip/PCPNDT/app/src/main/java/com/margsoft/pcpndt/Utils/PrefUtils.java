package com.margsoft.pcpndt.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PrefUtils {
    public static final String Id = "Id";
    public static final String Username = "Username";
    public static final String Address = "Address";
    public static final String Start_Status = "Start_Status";
    public static final String Mobile = "Mobile";
    public static final String Name = "Name";
    public static final String Number = "Number";
    public static final String Inspection_Id = "Inspection_Id";
    public static final String Center_Address = "Center_Address";
    public static final String Center_Name = "Center_Name";
    public static final String Date = "Date";
    public static final String Remark = "Remark";
    public static final String Decoy = "Decoy";
   // public static final String Inspection_Id = "Inspection_Id";
    private static SharedPreferences preferences = null;

    public static String saveToPrefs(Context context, String key, String value) {
        SharedPreferences prefs = PreferenceManager
                .getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, value);
        editor.apply();
        return key;
    }
    public static String getFromPrefs(Context context, String key) {
        SharedPreferences sharedPrefs = PreferenceManager
                .getDefaultSharedPreferences(context);
        try {
            return sharedPrefs.getString(key, "");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    public static void removeFromSharedPreferences(Context context, String key) {
        if (context != null) {
            SharedPreferences sharedPrefs = PreferenceManager
                    .getDefaultSharedPreferences(context);
            if (sharedPrefs != null)
                sharedPrefs.edit().remove(key).commit();
        }
    }
}

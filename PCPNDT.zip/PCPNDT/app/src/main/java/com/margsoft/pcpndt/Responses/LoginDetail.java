package com.margsoft.pcpndt.Responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class LoginDetail {
    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("UserType")
    @Expose
    private Integer userType;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Phone")
    @Expose
    private String phone;
    @SerializedName("Address")
    @Expose
    private String address;
//    @SerializedName("IsActive")
//    @Expose
//    private Boolean isActive;
    @SerializedName("District")
    @Expose
    private List<LoginDistrict> district;
    @SerializedName("Division")
    @Expose
    private List<LoginDivision> division;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

//    public Boolean getIsActive() {
//        return isActive;
//    }
//
//    public void setIsActive(Boolean isActive) {
//        this.isActive = isActive;
//    }

    public List<LoginDistrict> getDistrict() {
        return district;
    }

    public void setDistrict(List<LoginDistrict> district) {
        this.district = district;
    }

    public List<LoginDivision> getDivision() {
        return division;
    }

    public void setDivision(List<LoginDivision> division) {
        this.division = division;
    }

}

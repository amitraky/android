package com.margsoft.pcpndt.APIs;

import com.margsoft.pcpndt.Responses.InspecResponse;
import com.margsoft.pcpndt.Responses.LoginResponse;
import com.margsoft.pcpndt.Responses.SubmitResponse;
import com.margsoft.pcpndt.Responses.TokenResponse;
import com.margsoft.pcpndt.Responses.UpdateProResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RestApiService {
    @GET("get_token")
    Call<TokenResponse> token_generate(@Query("mobile") String mobile);

    @GET("verify_token")
    Call<LoginResponse> verify_token(@Query("mobile") String mobile,
                                     @Query("token") String token);

    @GET("get_inspaction_completed")
    Call<InspecResponse> get_inspection_list_completed(@Query("id") String id);

    @GET("get_inspaction_inprocess")
    Call<InspecResponse> get_inspection_list_pending(@Query("id") String id);

    @FormUrlEncoded
    @POST("set_inspaction")
    Call<SubmitResponse> submit_inspection(@Field("id") String id,
                                           @Field("inspection_report") String inspection_report);

    @FormUrlEncoded
    @POST("update_profile")
    Call<UpdateProResponse> update_profile(@Field("id") String id,
                                       @Field("name") String name,
                                       @Field("mobile") String mobile,
                                       @Field("email") String email,
                                       @Field("address") String address);
}
package com.margsoft.pcpndt.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.margsoft.pcpndt.APIs.ApiClient;
import com.margsoft.pcpndt.APIs.RestApiService;
import com.margsoft.pcpndt.Database.DbHelper;
import com.margsoft.pcpndt.Model.InspectionReport;
import com.margsoft.pcpndt.Model.Questionnaire;
import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Responses.InspecResponse;
import com.margsoft.pcpndt.Responses.SubmitResponse;
import com.margsoft.pcpndt.Responses.TokenResponse;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChecklistActivity extends AppCompatActivity {
    TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7,tv8;
    RadioGroup radio_1,radio_2,radio_3,radio_4,radio_7,radio_8;
    EditText remark1, remark2,remark3,remark4,remark5,remark7,remark8,remark_inspection;
    CheckBox checkBox1, checkBox2, checkBox3;
    String ans,checkbox_str1,checkbox_str2,checkbox_str3,spinner_value;
    Button submit;
    Spinner floors_spinner;
    List<Questionnaire> questionnaireList = new ArrayList<>();
    List<InspectionReport> inspectionReports = new ArrayList<>();
    InspectionReport inspection = new InspectionReport();
    boolean complete_data =false;
    ProgressDialog progressDialog;

    private FusedLocationProviderClient mFusedLocationClient;
    private int PERMISSION_ID = 44;
    private LocationManager locationManager;
    String geolocation_str;
    DbHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checklist);
        dbHelper = new DbHelper(ChecklistActivity.this);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        String[] arraySpinner = new String[] {
                "Select Floor","1", "2", "3", "4", "5", "6", "7","8","9","10","11","12","13","14","15","16","17","18","19","20"
        };
        progressDialog = new ProgressDialog(ChecklistActivity.this);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        tv4 = findViewById(R.id.tv4);
        tv5 = findViewById(R.id.tv5);
        tv6 = findViewById(R.id.tv6);
        tv7 = findViewById(R.id.tv7);
        tv8 = findViewById(R.id.tv8);

        radio_1 = findViewById(R.id.radio_1);
        radio_2 = findViewById(R.id.radio_2);
        radio_3 = findViewById(R.id.radio_3);
        radio_4 = findViewById(R.id.radio_4);
        radio_7 = findViewById(R.id.radio_7);
        radio_8 = findViewById(R.id.radio_8);


        remark1 = findViewById(R.id.remark1);
        remark2 = findViewById(R.id.remark2);
        remark3 = findViewById(R.id.remark3);
        remark4 = findViewById(R.id.remark4);
        remark5 = findViewById(R.id.remark5);
        remark7 = findViewById(R.id.remark7);
        remark8 = findViewById(R.id.remark8);

        remark_inspection = findViewById(R.id.remark_inspection);

        checkBox1 = findViewById(R.id.checkbox1);
        checkBox2 = findViewById(R.id.checkbox2);
        checkBox3 = findViewById(R.id.checkbox3);

        floors_spinner = findViewById(R.id.floors_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        floors_spinner.setAdapter(adapter);

        floors_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner_value = floors_spinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        submit = findViewById(R.id.submit);

        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data1();

                if(complete_data){
                    InspectionReport inspectionReport = new InspectionReport();
                    inspectionReport.setQuestionnaire(questionnaireList);
                    inspectionReport.setDate(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Date));
                    inspectionReport.setCenterAddress(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Center_Address));
                    inspectionReport.setCenterName(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Center_Name));
                    inspectionReport.setDecoyClient(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Decoy));
                    inspectionReport.setId(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Inspection_Id));
                    inspectionReport.setRemark1(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Remark));
                    inspectionReport.setRemark2(remark_inspection.getText().toString());
                    inspectionReport.setGeolocation(geolocation_str);
                    inspectionReports.add(inspectionReport);
                    GsonBuilder gsonBuilder = new GsonBuilder();
                    Gson gson = gsonBuilder.create();
                    String JSONObject = gson.toJson(inspectionReport);
                    Gson prettyGson = new GsonBuilder().setPrettyPrinting().create();
                    String prettyJson = prettyGson.toJson(inspectionReport);
                    SendData(prettyJson);
//                    Toast.makeText(ChecklistActivity.this,prettyJson,Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void  SendData(final String data){
        progressDialog.setMessage("Submitting Data...");
        progressDialog.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_design));
        progressDialog.setCancelable(false);
        progressDialog.show();
        String id = PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Inspection_Id);
        RestApiService authApiHelper = ApiClient.getClient_minetag(this).create(RestApiService.class);
        Call<SubmitResponse> call2 = authApiHelper.submit_inspection(id,data);
        call2.enqueue(new Callback<SubmitResponse>() {
            @Override
            public void onResponse(Call<SubmitResponse> call, Response<SubmitResponse> response) {
                final SubmitResponse userList = response.body();
                if(userList.getError()==0){
                    progressDialog.dismiss();
                    Toast.makeText(ChecklistActivity.this,userList.getMessage(),Toast.LENGTH_SHORT).show();
//                    Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
//                    startActivity(intent);
//                    Toast.makeText(LoginActivity.this,userList.getResults().getToken().toString(),Toast.LENGTH_SHORT).show();
//                    PrefUtils.saveToPrefs(LoginActivity.this,PrefUtils.Number,phone_number);
                }
//                if (userList.getStatus() != 0) {
//                }
            }
            @Override
            public void onFailure(Call<SubmitResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(ChecklistActivity.this, "fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }
    public void logout(View v){
        Toast.makeText(ChecklistActivity.this,"LOGOUT",Toast.LENGTH_SHORT).show();
    }
    public void data1(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv1.getText().toString());
        if(radio_1.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else{
            RadioButton uans = (RadioButton) findViewById(radio_1.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark1.getText().toString());
            questionnaireList.add(questionnaire);
            data2();
        }
    }
    public void data2(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv2.getText().toString());
        if(radio_2.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton uans = (RadioButton) findViewById(radio_2.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark2.getText().toString());
            questionnaireList.add(questionnaire);
            data3();
        }
    }
    public void data3(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv3.getText().toString());
        if(radio_3.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton uans = (RadioButton) findViewById(radio_3.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark3.getText().toString());
            questionnaireList.add(questionnaire);
            data4();
        }
    }
    public void data4(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv4.getText().toString());
        if(radio_4.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton uans = (RadioButton) findViewById(radio_4.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark4.getText().toString());
            questionnaireList.add(questionnaire);
            data5();
        }
    }
    public void data5(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv5.getText().toString());
        if(checkBox1.isChecked()){
            checkbox_str1 = checkBox1.getText().toString();
        }
        if(checkBox2.isChecked()){
            checkbox_str2 = checkBox2.getText().toString();
        }
        if(checkBox3.isChecked()){
            checkbox_str3 = checkBox3.getText().toString();
        }
        questionnaire.setAns(checkbox_str1+", "+checkbox_str2+", "+checkbox_str3);
        questionnaire.setRemark(remark5.getText().toString());
        questionnaireList.add(questionnaire);
        data6();
//        if(checkbox_str1.isEmpty()&& checkbox_str2.isEmpty() && checkbox_str3.isEmpty()){
//            Toast.makeText(ChecklistActivity.this,"All ans are mandtory",Toast.LENGTH_SHORT).show();
//        }
//        else{
//
//
//        }
    }
    public void data6(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv6.getText().toString());
        if(spinner_value.equals("Select Floor")|| spinner_value.isEmpty()){
            Toast.makeText(ChecklistActivity.this,"Please Select floor",Toast.LENGTH_SHORT).show();
        }
        else{
            questionnaire.setAns(spinner_value);
            questionnaire.setRemark("No remark");
            questionnaireList.add(questionnaire);
            data7();
        }
    }
    public void data7(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv7.getText().toString());
        if(radio_7.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton uans = (RadioButton) findViewById(radio_7.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark7.getText().toString());
            questionnaireList.add(questionnaire);
            data8();
        }
    }
    public void data8(){
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setTitle(tv8.getText().toString());
        if(radio_8.getCheckedRadioButtonId() == -1){
            Toast.makeText(ChecklistActivity.this,"All ans are mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton uans = (RadioButton) findViewById(radio_8.getCheckedRadioButtonId());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark8.getText().toString());
            questionnaireList.add(questionnaire);
        }
        complete_data = true;
    }
    @Override
    public void onResume() {
        super.onResume();
        if (checkPermissions()) {
            getLastLocation();
//            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  'at' HH:mm:ss ");
//            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd ");
//            datetosend = sdf1.format(new Date());
//            String currentDateandTime = sdf.format(new Date());
//            datentime.setText(currentDateandTime);
        }
    }

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(ChecklistActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(ChecklistActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        return false;
    }
    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                PERMISSION_ID
        );
    }
    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        );
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                try {
                    getLastLocation();
                } catch (Exception ex) {
                }
            }
        }
    }
    @SuppressLint("MissingPermission")
    private void getLastLocation() {
        if (checkPermissions()) {
            if (isLocationEnabled()) {
                mFusedLocationClient.getLastLocation().addOnCompleteListener(
                        new OnCompleteListener<Location>() {
                            @Override
                            public void onComplete(@NonNull Task<Location> task) {
                                Location location = task.getResult();
                                if (location == null) {
                                    requestNewLocationData();
                                } else {
                                    String latitude_str = location.getLatitude() + "";
                                    String longitude_str = location.getLongitude() + "";
                                    geolocation_str=latitude_str + " , " + longitude_str;
                                }
                            }
                        });
            } else {
                Toast.makeText(ChecklistActivity.this, "Turn on location", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {
            requestPermissions();
        }
    }
    @SuppressLint("MissingPermission")
    private void requestNewLocationData() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(0);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(ChecklistActivity.this);
        mFusedLocationClient.requestLocationUpdates(
                mLocationRequest, mLocationCallback,
                Looper.myLooper()
        );
    }
    private LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
        }
    };




    public void SaveDataLoacal(){
        if(radio_1.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_1.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv1.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark1.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);

        }
        if(radio_2.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_2.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv2.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark2.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);

        }
        if(radio_3.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_3.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv3.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark3.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);

        }
        if(radio_4.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_4.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv4.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark4.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);
        }
        if(checkBox1.isChecked() || checkBox2.isChecked() || checkBox2.isChecked()) {
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv5.getText().toString());
            if (checkBox1.isChecked()) {
                checkbox_str1 = checkBox1.getText().toString();
            }
            if (checkBox2.isChecked()) {
                checkbox_str2 = checkBox2.getText().toString();
            }
            if (checkBox3.isChecked()) {
                checkbox_str3 = checkBox3.getText().toString();
            }
            questionnaire.setAns(checkbox_str1 + ", " + checkbox_str2 + ", " + checkbox_str3);
            questionnaire.setRemark(remark5.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);
        }
        if(!spinner_value.equals("Select Floor")){
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv6.getText().toString());
            questionnaire.setAns(spinner_value);
            questionnaire.setRemark("No remark");
            long i = dbHelper.addLocalData(questionnaire);
        }
        if(radio_7.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_7.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv7.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark7.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);
        }
        if(radio_8.getCheckedRadioButtonId() != -1){
            RadioButton uans = (RadioButton) findViewById(radio_8.getCheckedRadioButtonId());
            Questionnaire questionnaire = new Questionnaire();
            questionnaire.setTitle(tv8.getText().toString());
            ans = uans.getText().toString();
            questionnaire.setAns(ans);
            questionnaire.setRemark(remark8.getText().toString());
            long i = dbHelper.addLocalData(questionnaire);
        }

        List<Questionnaire> questionnaires_db = new ArrayList<>();
        questionnaires_db = dbHelper.getAll();
        InspectionReport inspectionReport = new InspectionReport();
        inspectionReport.setQuestionnaire(questionnaires_db);
        inspectionReport.setDate(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Date));
        inspectionReport.setCenterAddress(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Center_Address));
        inspectionReport.setCenterName(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Center_Name));
        inspectionReport.setDecoyClient(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Decoy));
        inspectionReport.setId(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Inspection_Id));
        inspectionReport.setRemark1(PrefUtils.getFromPrefs(ChecklistActivity.this,PrefUtils.Remark));
        inspectionReport.setRemark2(remark_inspection.getText().toString());
        inspectionReport.setGeolocation(geolocation_str);

        Toast.makeText(ChecklistActivity.this, questionnaires_db.size(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        SaveDataLoacal();
    }
}
package com.margsoft.pcpndt.Responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InspecList {
    @SerializedName("IsDecoyClient")
    @Expose
    private String isDecoyClient;
    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("IsRegisteredCenter")
    @Expose
    private String isRegisteredCenter;
    @SerializedName("CenterKey")
    @Expose
    private int centerKey;
    @SerializedName("UnRegCentreName")
    @Expose
    private String unRegCentreName;
    @SerializedName("ControlNo")
    @Expose
    private String controlNo;
    @SerializedName("UnRegCentreAddress")
    @Expose
    private String unRegCentreAddress;
    @SerializedName("InspectionDate")
    @Expose
    private String inspectionDate;
    @SerializedName("Remark")
    @Expose
    private String remark;
    @SerializedName("InspectionReport")
    @Expose
    private String inspectionReport;
    @SerializedName("InspectionKey")
    @Expose
    private int inspectionKey;
    @SerializedName("CreatedBy")
    @Expose
    private int createdBy;
    @SerializedName("CreatedOn")
    @Expose
    private String createdOn;
    @SerializedName("LastModifiedBy")
    @Expose
    private int lastModifiedBy;
    @SerializedName("LastModifiedOn")
    @Expose
    private String lastModifiedOn;
    @SerializedName("DistrictKey")
    @Expose
    private int districtKey;
    @SerializedName("__v")
    @Expose
    private int v;
    @SerializedName("InspectionUsers")
    @Expose
    private String inspectionUsers;

    public String getIsDecoyClient() {
        return isDecoyClient;
    }

    public void setIsDecoyClient(String isDecoyClient) {
        this.isDecoyClient = isDecoyClient;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsRegisteredCenter() {
        return isRegisteredCenter;
    }

    public void setIsRegisteredCenter(String isRegisteredCenter) {
        this.isRegisteredCenter = isRegisteredCenter;
    }

    public int getCenterKey() {
        return centerKey;
    }

    public void setCenterKey(int centerKey) {
        this.centerKey = centerKey;
    }

    public String getUnRegCentreName() {
        return unRegCentreName;
    }

    public void setUnRegCentreName(String unRegCentreName) {
        this.unRegCentreName = unRegCentreName;
    }

    public String getControlNo() {
        return controlNo;
    }

    public void setControlNo(String controlNo) {
        this.controlNo = controlNo;
    }

    public String getUnRegCentreAddress() {
        return unRegCentreAddress;
    }

    public void setUnRegCentreAddress(String unRegCentreAddress) {
        this.unRegCentreAddress = unRegCentreAddress;
    }

    public String getInspectionDate() {
        return inspectionDate;
    }

    public void setInspectionDate(String inspectionDate) {
        this.inspectionDate = inspectionDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getInspectionReport() {
        return inspectionReport;
    }

    public void setInspectionReport(String inspectionReport) {
        this.inspectionReport = inspectionReport;
    }

    public int getInspectionKey() {
        return inspectionKey;
    }

    public void setInspectionKey(int inspectionKey) {
        this.inspectionKey = inspectionKey;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public int getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(int lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(String lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public int getDistrictKey() {
        return districtKey;
    }

    public void setDistrictKey(int districtKey) {
        this.districtKey = districtKey;
    }

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }

    public String getInspectionUsers() {
        return inspectionUsers;
    }

    public void setInspectionUsers(String inspectionUsers) {
        this.inspectionUsers = inspectionUsers;
    }

}

package com.margsoft.pcpndt.Responses;

public class VerificationResponse {
}

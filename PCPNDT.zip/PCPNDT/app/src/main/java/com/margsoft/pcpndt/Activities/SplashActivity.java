package com.margsoft.pcpndt.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.margsoft.pcpndt.R;
import com.margsoft.pcpndt.Utils.PrefUtils;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
    private final int REQUEST_LOCATION = 100;
    private final int SettingLocation=101;
    private Timer timer;
    private ProgressBar progressBar;
    private int i=0;
    TextView textView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        progressBar.setProgress(0);
        textView=(TextView)findViewById(R.id.textView);
        textView.setText("");
        final long period = 40;
        timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (i<100){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView.setText(String.valueOf(i)+"%");
                        }
                    });
                    progressBar.setProgress(i);
                    i++;
                }else{
                    timer.cancel();
                    updateUI();
                }
            }
        }, 0, period);
    }
    private void updateUI() {
        if(PrefUtils.getFromPrefs(SplashActivity.this, PrefUtils.Start_Status).equals("1") ){
            Intent splash = new Intent(SplashActivity.this, MainActivity .class);
            startActivity(splash);
            finish();
        }else {
            Intent splash = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(splash);
            finish();
        }
    }
    @Override
    public void onStart() {
        super.onStart();
    }
    @Override
    public void onStop() {
        super.onStop();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e("splash","oNActivityResult called");
        if (requestCode == REQUEST_LOCATION ) {
            if (resultCode==RESULT_OK){
                updateUI();
            }else{
                finish();
            }
        }
        else if(requestCode==SettingLocation){
            if (resultCode==RESULT_OK){
                updateUI();
            }else{
                finish();
            }
        }
    }
}
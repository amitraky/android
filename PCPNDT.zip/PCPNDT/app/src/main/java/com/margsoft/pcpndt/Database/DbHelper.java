package com.margsoft.pcpndt.Database;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.margsoft.pcpndt.Model.Questionnaire;

import java.util.ArrayList;


public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;
    private static final String DATABASE_NAME = "vessel_database";

    private static final String LOCALDATA = "localdata";


    private static final String KEY_ID = "id";

    private static final String TITLE = "title";
    private static final String ANSWER = "answer";
    private static final String REMARK = "remark";
    private static final String QUESTION_ID = "questionid";
    private static final String KEY_RADIO = "answer_key";
    private static final String PRESENT_CONDITION = "present_condition";
    private static final String ACTION_REQUIRED = "action_reuired";
    private static final String DUE_AFTER = "due";
    private static final String HOURS = "hours";
    private static final String  IMAGE = "image";
    private static final String  INFO_TEXT = "info_text";
    private static final String  LAST_VALUE = "last_value";
    private static final String  QUESTION_COUNT = "question_count";
    private static final String  ANSWERED_STATUS = "answered_status";
    private static final String  FILE_NAME = "file_name";
    private static final String  COMMENT = "comment";

    private static final String CREATE_MAIN_TABLE = "CREATE TABLE IF NOT EXISTS "
            + LOCALDATA + "(" + KEY_ID + " INTEGER PRIMARY KEY," + TITLE + " TEXT,"
            + ANSWER+ " TEXT," + REMARK  + " TEXT" +")";


    Context context;
    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_MAIN_TABLE);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + LOCALDATA);
        onCreate(db);
    }
    //----------------------------------------------------------------------Local Data------------------------------------------------------------------------------
    public long addLocalData(Questionnaire model ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TITLE, model.getTitle());
        values.put(ANSWER, model.getAns());
        values.put(REMARK, model.getRemark());
        long r= db.insert(LOCALDATA, null, values);
        db.close();
        return r;
    }
    public ArrayList<Questionnaire> getAll() {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM " + LOCALDATA , null);
        ArrayList<Questionnaire> tableModels = new ArrayList<Questionnaire>();
        Questionnaire model;
        if (cursor.getCount() > 0) {
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                model = new Questionnaire();
                model.setRemark(cursor.getString(cursor.getColumnIndex(REMARK)));
                model.setAns(cursor.getString(cursor.getColumnIndex(ANSWER)));
                model.setTitle(cursor.getString(cursor.getColumnIndex(TITLE)));
                tableModels.add(model);
            }
        }
        cursor.close();
        database.close();
        return tableModels;
    }
//    public ArrayList<TableModel> getPreviousAns(int questionid, int categoryid) {
//        SQLiteDatabase database = this.getReadableDatabase();
//        Cursor cursor = database.rawQuery( "select * from localdata where categoryid=" + categoryid + " and questionid=" + questionid +"", null);
//        ArrayList<TableModel> contacts = new ArrayList<TableModel>();
//        TableModel contactModel;
//        if (cursor.getCount() > 0) {
//            for (int i = 0; i < cursor.getCount(); i++) {
//                cursor.moveToNext();
//                contactModel = new TableModel();
//                contactModel.setCategory_id(cursor.getString(cursor.getColumnIndex(CATEGORY_ID)));
//                contactModel.setQuestion_id(cursor.getString(cursor.getColumnIndex(QUESTION_ID)));
//                contactModel.setKey_radio(cursor.getString(cursor.getColumnIndex(KEY_RADIO)));
//                contactModel.setAction_required(cursor.getString(cursor.getColumnIndex(ACTION_REQUIRED)));
//                contactModel.setPresent_condition(cursor.getString(cursor.getColumnIndex(PRESENT_CONDITION)));
//                contactModel.setDue_after(cursor.getString(cursor.getColumnIndex(DUE_AFTER)));
//                contactModel.setHours(cursor.getString(cursor.getColumnIndex(HOURS)));
//                contacts.add(contactModel);
//            }
//        }
//        cursor.close();
//        database.close();
//        return contacts;
//    }
//    public int getCount(int categoryid) {
//        SQLiteDatabase database = this.getReadableDatabase();
//        Cursor cursor = database.rawQuery( "select * from localdata where categoryid="+  categoryid +"", null);
//        if (cursor.getCount() > 0) {
//            for (int i = 0; i < cursor.getCount(); i++) {
//                cursor.moveToNext();
//            }
//        }
//        cursor.close();
//        database.close();
//        return cursor.getCount();
//    }
//    public int updateName(int categoryid , int questionid, String keyvalue, String pre_condition, String action, String due, String hrs) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put(DbHelper.KEY_RADIO,keyvalue);
//        contentValues.put(DbHelper.PRESENT_CONDITION,pre_condition);
//        contentValues.put(DbHelper.ACTION_REQUIRED,action);
//        contentValues.put(DbHelper.DUE_AFTER,due);
//        contentValues.put(DbHelper.HOURS,hrs);
//        int count =db.update(DbHelper.LOCALDATA,contentValues, "categoryid=" + categoryid + " and questionid=" + questionid,null );
//        return count;
//    }
//    public void deleteAllLocalData() {
//        SQLiteDatabase db = this.getWritableDatabase();
//        db.execSQL("delete from " + LOCALDATA );
//        db.close();
//    }

}
